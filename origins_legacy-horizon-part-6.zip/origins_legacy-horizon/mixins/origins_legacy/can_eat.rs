// Player.canEat for a food: Arachnid (carnivore) and Avian (vegetarian) refuse the food outside their diet.
fn origins_legacy_can_eat(game: &crate::game::Game<'_>, stack: &ItemStack, can_eat: &mut bool) {
    crate::game::port_origins_legacy_game::on_can_eat(game, &stack.item, can_eat);
}
