// Origins as data and the rules that don't need the game: the ten origins of the mod (from its
// `data/origins/origins/*.json`), the powers each has, one small text file of choice per player,
// the `/origin` commands, and what a power does to damage and to breathing.
//
// This file is injected into horizon-core (noise/mod.rs, `pub`) so that every crate the hooks live in
// (horizon-client's game, horizon-client-lib's breathing) reaches the same table of who has which
// origin (`state`), as Classic Farlands shares its settings.

/// `(id, impact 0..=3, powers)`: the origins of the mod in the order of its selection screen.
pub const ORIGINS: &[(&str, u8, &[&str])] = &[
    ("origins:human", 0, &[]),
    ("origins:enderian", 2, &["throw_ender_pearl", "water_vulnerability", "pumpkin_hate", "extra_reach", "ender_particles", "damage_from_potions"]),
    ("origins:merling", 3, &["water_breathing", "water_vision", "aqua_affinity", "swim_speed", "like_water", "aquatic", "conduit_power_on_land", "air_from_potions"]),
    ("origins:phantom", 3, &["phantomize", "translucent", "phasing", "invisibility", "burn_in_daylight", "hunger_over_time", "fragile", "phantomize_overlay"]),
    ("origins:elytrian", 1, &["elytra", "launch_into_air", "aerial_combatant", "light_armor", "claustrophobia", "more_kinetic_damage"]),
    ("origins:blazeborn", 3, &["fire_immunity", "nether_spawn", "burning_wrath", "hotblooded", "water_vulnerability", "flame_particles", "damage_from_snowballs", "damage_from_potions"]),
    ("origins:avian", 1, &["slow_falling", "fresh_air", "like_air", "tailwind", "lay_eggs", "vegetarian"]),
    ("origins:arachnid", 1, &["climbing", "master_of_webs", "carnivore", "fragile", "arthropod"]),
    ("origins:shulk", 1, &["shulker_inventory", "natural_armor", "strong_arms", "strong_arms_break_speed", "no_shield", "more_exhaustion"]),
    ("origins:feline", 2, &["fall_immunity", "sprint_jump", "velvet_paws", "nine_lives", "weak_arms", "scare_creepers", "cat_vision"]),
];

/// The powers this port runs so far. The rest of the 61 are listed by `/origin powers` with a `(not yet)`.
pub const IMPLEMENTED_POWERS: &[&str] = &[
    "water_breathing", "fall_immunity", "fire_immunity", "cat_vision", "hotblooded",
    "fragile", "nine_lives", "natural_armor", "tailwind", "extra_reach",
    "more_kinetic_damage", "damage_from_potions", "carnivore", "vegetarian", "no_shield",
    "slow_falling",
];

/// `merling` as `origins:merling`; an id with a namespace is left as it is.
pub fn normalize(name: &str) -> String {
    let lower = name.trim().to_ascii_lowercase();
    if lower.contains(':') {
        lower
    } else {
        format!("origins:{lower}")
    }
}

pub fn find(id: &str) -> Option<&'static (&'static str, u8, &'static [&'static str])> {
    ORIGINS.iter().find(|o| o.0 == id)
}

pub fn has_power(origin: &str, power: &str) -> bool {
    find(origin).is_some_and(|o| o.2.contains(&power))
}

/// `origins:merling` as `Merling`.
pub fn display(id: &str) -> String {
    let short = id.rsplit(':').next().unwrap_or(id);
    let mut chars = short.chars();
    match chars.next() {
        Some(c) => c.to_ascii_uppercase().to_string() + chars.as_str(),
        None => String::new(),
    }
}

pub fn impact_name(impact: u8) -> &'static str {
    match impact {
        0 => "none",
        1 => "low",
        2 => "medium",
        _ => "high",
    }
}

// ---- What a power does ----------------------------------------------------------------

/// `minecraft:is_fire`'s damage types, what `origins:fire` matches.
const FIRE_DAMAGE: &[&str] = &["in_fire", "campfire", "on_fire", "lava", "hot_floor", "unattributed_fire"];

/// `minecraft:fall` as `fall`.
fn short(damage_type: &str) -> &str {
    damage_type.rsplit(':').next().unwrap_or(damage_type)
}

/// `origins:invulnerability`: Feline's `fall_immunity` (damage named `fall`) and Blazeborn's
/// `fire_immunity` (fire damage).
pub fn invulnerable_to(origin: &str, damage_type: &str) -> bool {
    let kind = short(damage_type);
    (has_power(origin, "fall_immunity") && kind == "fall")
        || (has_power(origin, "fire_immunity") && FIRE_DAMAGE.contains(&kind))
}

/// `origins:modify_damage_taken`: Elytrian's `more_kinetic_damage`, +50% (`multiply_base` 0.5) of fall and
/// fly-into-wall damage. The number the damage is multiplied by; 1.0 changes nothing.
pub fn damage_taken_factor(origin: &str, damage_type: &str) -> f32 {
    if has_power(origin, "more_kinetic_damage") && matches!(short(damage_type), "fall" | "fly_into_wall") {
        1.5
    } else {
        1.0
    }
}

// ---- Powers that are rules about items ---------------------------------------------------------

/// The jar's `origins:meat` item tag (`data/origins/tags/item/meat.json`). The `origins:meat` condition of the
/// original (a food property) is not separate here: the game only asks about food (`can_eat`), and an item
/// outside this list counts as not meat.
pub const MEAT: &[&str] = &[
    "minecraft:rotten_flesh", "minecraft:cod", "minecraft:tropical_fish", "minecraft:pufferfish", "minecraft:salmon",
    "minecraft:beef", "minecraft:porkchop", "minecraft:mutton", "minecraft:chicken", "minecraft:rabbit",
    "minecraft:cooked_chicken", "minecraft:cooked_rabbit", "minecraft:rabbit_stew", "minecraft:cooked_porkchop",
    "minecraft:cooked_cod", "minecraft:cooked_beef", "minecraft:cooked_mutton", "minecraft:cooked_salmon",
    "minecraft:spider_eye",
];

pub fn is_meat(item: &str) -> bool {
    MEAT.contains(&item)
}

/// May a player of this origin start eating the food `item`? Arachnid's `carnivore` refuses what is not meat,
/// Avian's `vegetarian` refuses meat (`origins:prevent_item_use`, the `origins:ignore_diet` tag is empty).
pub fn may_eat(origin: &str, item: &str) -> bool {
    if has_power(origin, "carnivore") && !is_meat(item) {
        return false;
    }
    if has_power(origin, "vegetarian") && is_meat(item) {
        return false;
    }
    true
}

/// May a player of this origin start using `item` (hold it up, draw it)? Shulk's `no_shield` refuses shields.
pub fn may_use(origin: &str, item: &str) -> bool {
    !(has_power(origin, "no_shield") && item == "minecraft:shield")
}

/// Enderian's `damage_from_potions`: 2 damage (a heart) on drinking a potion, as the command that does it. The
/// original's `origins:hurt_by_water` damage type is not in Horizon; `minecraft:magic` is the nearest, and like it
/// ignores armor.
pub fn potion_damage_command(name: &str) -> Option<String> {
    is_plain_name(name).then(|| format!("damage {name} 2 minecraft:magic"))
}

/// Merling's `water_breathing` (WaterBreathingMixin): the air logic turned round. Under water the
/// air refills, on land it runs out. `vanilla` is whether the game says the player can breathe.
pub fn can_breathe(origin: &str, vanilla: bool) -> bool {
    if has_power(origin, "water_breathing") {
        !vanilla
    } else {
        vanilla
    }
}

// ---- Powers that are status effects ---------------------------------------------------------
//
// Done with the game's own `/effect`, run from the server's tick once a second (`state::due`).
// `/effect` works on any player. The powers that are attribute modifiers are below.

/// Powers that keep a status effect on the player: `(power, effect, seconds, amplifier)`. The effect is
/// given again every second with a duration well past the ten seconds where night vision starts to
/// flicker.
///
/// Approximate: Feline `cat_vision` (origins:night_vision, strength 0.4, off under water) becomes the
/// whole night vision effect with hidden particles, and it is not switched off under water.
pub const EFFECT_POWERS: &[(&str, &str, u32, u32)] = &[
    ("cat_vision", "minecraft:night_vision", 30, 0),
    // Approximate: Avian `slow_falling` (apoli:modify_falling, velocity 0.01, no fall damage) is the game's own
    // slow falling effect, which does the same. The original is switched off by sneaking (and on by sneaking while
    // gliding); the effect cannot be, because the port cannot read whether a player sneaks. Short, so it ends
    // within seconds of changing origin.
    ("slow_falling", "minecraft:slow_falling", 5, 0),
];

/// Powers that remove effects as they appear: `(power, effects)`. Blazeborn `hotblooded`
/// (origins:effect_immunity).
pub const IMMUNITY_POWERS: &[(&str, &[&str])] = &[("hotblooded", &["minecraft:poison", "minecraft:hunger"])];

/// A profile name that is safe to put in a command: 1 to 16 letters, digits and underscores.
pub fn is_plain_name(name: &str) -> bool {
    !name.is_empty() && name.len() <= 16 && name.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
}

/// The commands (without the slash) that put a player's effect powers in force for one second.
/// Nothing for a player with no origin, or a name that is not plain.
pub fn effect_commands(origin: Option<&str>, name: &str) -> Vec<String> {
    let Some(origin) = origin else {
        return Vec::new();
    };
    if !is_plain_name(name) {
        return Vec::new();
    }
    let mut out = Vec::new();
    for (power, effect, seconds, amplifier) in EFFECT_POWERS {
        if has_power(origin, power) {
            out.push(format!("effect give {name} {effect} {seconds} {amplifier} true"));
        }
    }
    for (power, effects) in IMMUNITY_POWERS {
        if has_power(origin, power) {
            for effect in *effects {
                out.push(format!("effect clear {name} {effect}"));
            }
        }
    }
    out
}

// ---- Powers that are attribute modifiers ----------------------------------------------------
//
// Done with the game's `/attribute <player> <attribute> modifier add|remove`, from the server's tick
// once a second. Horizon's `/attribute` only reached the host's own player and mobs until
// `horizon-patches/0001-attribute-command-reaches-guests.patch`: without it the commands fail for the
// players of a hosted world or server, and these powers do nothing there.

/// A modifier a power puts on a player. `attribute` is the 26.3 id (the jar's data names the old
/// `generic.*` ones), `operation` the command's word for the jar's `addition` / `multiply_base`.
pub struct AttributeMod {
    pub power: &'static str,
    pub attribute: &'static str,
    /// The modifier's id: ours, so removing it leaves everyone else's alone.
    pub id: &'static str,
    pub value: f64,
    pub operation: &'static str,
}

/// Every modifier any power here puts on a player.
pub const ATTRIBUTE_MODS: &[AttributeMod] = &[
    AttributeMod { power: "fragile", attribute: "minecraft:max_health", id: "origins_legacy:fragile", value: -6.0, operation: "add_value" },
    AttributeMod { power: "nine_lives", attribute: "minecraft:max_health", id: "origins_legacy:nine_lives", value: -2.0, operation: "add_value" },
    AttributeMod { power: "natural_armor", attribute: "minecraft:armor", id: "origins_legacy:natural_armor", value: 8.0, operation: "add_value" },
    AttributeMod { power: "tailwind", attribute: "minecraft:movement_speed", id: "origins_legacy:tailwind", value: 0.2, operation: "add_multiplied_base" },
    AttributeMod { power: "extra_reach", attribute: "minecraft:block_interaction_range", id: "origins_legacy:extra_reach_block", value: 1.5, operation: "add_value" },
    AttributeMod { power: "extra_reach", attribute: "minecraft:entity_interaction_range", id: "origins_legacy:extra_reach_entity", value: 1.5, operation: "add_value" },
];

fn add_command(name: &str, m: &AttributeMod) -> String {
    format!("attribute {name} {} modifier add {} {} {}", m.attribute, m.id, m.value, m.operation)
}

fn remove_command(name: &str, m: &AttributeMod) -> String {
    format!("attribute {name} {} modifier remove {}", m.attribute, m.id)
}

/// The commands that bring a player's modifiers in line with their origin, and the ids that hold after.
/// `applied` is what this session put on them last time (`None` the first time it sees them: a modifier
/// added by a command is saved with the player, so earlier ones may be there, and every modifier of ours
/// is removed before the right ones are added). A command that finds nothing to do (a modifier already
/// there, one that is not) only fails, which is harmless.
pub fn attribute_commands(
    applied: Option<&std::collections::BTreeSet<String>>,
    origin: Option<&str>,
    name: &str,
) -> (Vec<String>, std::collections::BTreeSet<String>) {
    let wanted: Vec<&AttributeMod> = match origin {
        Some(origin) if is_plain_name(name) => ATTRIBUTE_MODS.iter().filter(|m| has_power(origin, m.power)).collect(),
        _ => Vec::new(),
    };
    let wanted_ids: std::collections::BTreeSet<String> = wanted.iter().map(|m| m.id.to_owned()).collect();
    if !is_plain_name(name) {
        return (Vec::new(), applied.cloned().unwrap_or_default());
    }
    let mut out = Vec::new();
    match applied {
        None => {
            out.extend(ATTRIBUTE_MODS.iter().map(|m| remove_command(name, m)));
            out.extend(wanted.iter().map(|m| add_command(name, m)));
        }
        Some(have) => {
            out.extend(
                ATTRIBUTE_MODS
                    .iter()
                    .filter(|m| have.contains(m.id) && !wanted_ids.contains(m.id))
                    .map(|m| remove_command(name, m)),
            );
            out.extend(wanted.iter().filter(|m| !have.contains(m.id)).map(|m| add_command(name, m)));
        }
    }
    (out, wanted_ids)
}

// ---- Choice, saved per player ----------------------------------------------------------

/// `name=` and `origin=` lines.
pub fn choice_to_text(name: &str, origin: &str) -> String {
    format!("name={name}\norigin={origin}\n")
}

/// The saved origin, if it is one of the mod's.
pub fn choice_from_text(src: &str) -> Option<String> {
    src.lines()
        .filter_map(|l| l.split_once('='))
        .find(|(k, _)| k.trim() == "origin")
        .map(|(_, v)| v.trim().to_owned())
        .filter(|v| find(v).is_some())
}

// ---- /origin ---------------------------------------------------------------------------

/// The usages the mod registers, with the operator level each needs.
pub const COMMAND_USAGES: &[(&str, u8)] = &[
    ("origin get", 0),
    ("origin list", 0),
    ("origin powers", 0),
    ("origin set <origin:word>", 2),
];

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Command {
    Get,
    List,
    Powers,
    Set(String),
}

pub fn command_level(command: &Command) -> u8 {
    match command {
        Command::Set(_) => 2,
        _ => 0,
    }
}

/// Reads a command line without its slash. `None`: not ours. `Some(Err(usage))`: ours, wrong arguments.
pub fn parse_command(line: &str) -> Option<Result<Command, String>> {
    let mut words = line.split_whitespace();
    if words.next()? != "origin" {
        return None;
    }
    let sub = words.next();
    let arg = words.next();
    let extra = words.next();
    let parsed = match (sub, arg, extra) {
        (Some("get"), None, None) => Some(Command::Get),
        (Some("list"), None, None) => Some(Command::List),
        (Some("powers"), None, None) => Some(Command::Powers),
        (Some("set"), Some(o), None) => Some(Command::Set(normalize(o))),
        _ => None,
    };
    Some(parsed.ok_or_else(|| "Usage: /origin <get|list|powers|set <origin>>".to_owned()))
}

const TAG: &str = "\u{a7}6[Origins] \u{a7}f";

/// Runs a command for a player whose origin is `current`. Returns the lines to answer with and the
/// origin to save, if the command chose one.
pub fn run_command(current: Option<&str>, command: &Command) -> (Vec<String>, Option<String>) {
    match command {
        Command::Get => match current.and_then(find) {
            Some(o) => (
                vec![format!("{TAG}Your origin is {} (impact: {})", display(o.0), impact_name(o.1))],
                None,
            ),
            None => (vec![format!("{TAG}You have no origin. /origin list shows them.")], None),
        },
        Command::List => {
            let rows = ORIGINS
                .iter()
                .map(|o| format!("{} ({})", display(o.0), impact_name(o.1)))
                .collect::<Vec<_>>()
                .join(", ");
            (vec![format!("{TAG}{rows}")], None)
        }
        Command::Powers => match current.and_then(find) {
            Some(o) if o.2.is_empty() => (vec![format!("{TAG}{} has no powers.", display(o.0))], None),
            Some(o) => {
                let rows = o
                    .2
                    .iter()
                    .map(|p| {
                        if IMPLEMENTED_POWERS.contains(p) {
                            (*p).to_owned()
                        } else {
                            format!("{p} (not yet)")
                        }
                    })
                    .collect::<Vec<_>>()
                    .join(", ");
                (vec![format!("{TAG}{}: {rows}", display(o.0))], None)
            }
            None => (vec![format!("{TAG}You have no origin.")], None),
        },
        Command::Set(origin) => match find(origin) {
            Some(o) => (vec![format!("{TAG}Your origin is now {}", display(o.0))], Some(o.0.to_owned())),
            None => (vec![format!("{TAG}Unknown origin {origin}. /origin list shows them.")], None),
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_ten_origins_are_there_and_unique() {
        assert_eq!(ORIGINS.len(), 10);
        for (i, a) in ORIGINS.iter().enumerate() {
            assert!(a.0.starts_with("origins:"));
            assert!(ORIGINS.iter().skip(i + 1).all(|b| b.0 != a.0));
        }
    }

    #[test]
    fn implemented_powers_belong_to_an_origin() {
        for p in IMPLEMENTED_POWERS {
            assert!(ORIGINS.iter().any(|o| o.2.contains(p)), "{p}");
        }
    }

    #[test]
    fn normalizing_and_finding() {
        assert_eq!(normalize("Merling"), "origins:merling");
        assert_eq!(normalize("origins:feline"), "origins:feline");
        assert!(find("origins:merling").is_some());
        assert!(find("origins:nope").is_none());
        assert_eq!(display("origins:blazeborn"), "Blazeborn");
    }

    #[test]
    fn feline_ignores_falls_and_blazeborn_fire() {
        assert!(invulnerable_to("origins:feline", "minecraft:fall"));
        assert!(!invulnerable_to("origins:feline", "minecraft:lava"));
        assert!(invulnerable_to("origins:blazeborn", "minecraft:lava"));
        assert!(invulnerable_to("origins:blazeborn", "minecraft:in_fire"));
        assert!(invulnerable_to("origins:blazeborn", "minecraft:on_fire"));
        assert!(!invulnerable_to("origins:blazeborn", "minecraft:fall"));
        assert!(!invulnerable_to("origins:human", "minecraft:fall"));
        assert!(!invulnerable_to("origins:merling", "minecraft:lava"));
    }

    #[test]
    fn merling_breathes_the_other_way_round() {
        assert!(can_breathe("origins:merling", false)); // under water
        assert!(!can_breathe("origins:merling", true)); // on land
        assert!(can_breathe("origins:human", true));
        assert!(!can_breathe("origins:human", false));
    }

    #[test]
    fn choice_round_trips_and_rejects_unknown_origins() {
        let text = choice_to_text("Alex", "origins:avian");
        assert_eq!(choice_from_text(&text), Some("origins:avian".to_owned()));
        assert_eq!(choice_from_text("origin=origins:nope\n"), None);
        assert_eq!(choice_from_text("name=Alex\n"), None);
    }

    #[test]
    fn parses_commands() {
        assert_eq!(parse_command("say hi"), None);
        assert_eq!(parse_command("origin get"), Some(Ok(Command::Get)));
        assert_eq!(parse_command("origin list"), Some(Ok(Command::List)));
        assert_eq!(parse_command("origin powers"), Some(Ok(Command::Powers)));
        assert_eq!(
            parse_command("origin set Merling"),
            Some(Ok(Command::Set("origins:merling".to_owned())))
        );
        assert!(matches!(parse_command("origin set"), Some(Err(_))));
        assert!(matches!(parse_command("origin"), Some(Err(_))));
        assert!(matches!(parse_command("origin get x"), Some(Err(_))));
        assert_eq!(command_level(&Command::Get), 0);
        assert_eq!(command_level(&Command::Set("origins:avian".to_owned())), 2);
    }

    #[test]
    fn setting_an_origin_returns_it_to_save() {
        let (lines, save) = run_command(None, &Command::Set("origins:merling".to_owned()));
        assert_eq!(save.as_deref(), Some("origins:merling"));
        assert!(lines[0].contains("Merling"));
        let (lines, save) = run_command(None, &Command::Set("origins:nope".to_owned()));
        assert!(save.is_none() && lines[0].contains("Unknown"));
    }

    #[test]
    fn powers_marks_what_is_not_done() {
        let (lines, _) = run_command(Some("origins:merling"), &Command::Powers);
        assert!(lines[0].contains("water_breathing") && lines[0].contains("water_vision (not yet)"));
        assert!(!lines[0].contains("water_breathing (not yet)"));
        let (lines, _) = run_command(Some("origins:human"), &Command::Powers);
        assert!(lines[0].contains("no powers"));
        let (lines, _) = run_command(None, &Command::Get);
        assert!(lines[0].contains("no origin"));
    }
}

/// Who has which origin, shared by every hook. The game side fills it from the players' files (by uuid)
/// and from the player tick (by entity id, which is all that breathing and damage hooks are given).
pub mod state {
    use std::collections::HashMap;
    use std::sync::atomic::{AtomicU32, Ordering};
    use std::sync::{LazyLock, Mutex};

    static CALLS: AtomicU32 = AtomicU32::new(0);

    /// True on one call in every `every` (the first, then each `every`th after it): what spaces a once-a-second
    /// job out of a once-a-tick hook.
    pub fn due(every: u32) -> bool {
        CALLS.fetch_add(1, Ordering::Relaxed) % every.max(1) == 0
    }

    #[derive(Default)]
    struct Chosen {
        by_uuid: HashMap<u128, Option<String>>,
        by_entity: HashMap<i32, String>,
        applied: HashMap<u128, std::collections::BTreeSet<String>>,
        /// Players who drank a potion since the server's tick last looked (the hook cannot run a command).
        potions: Vec<u128>,
    }

    static CHOSEN: LazyLock<Mutex<Chosen>> = LazyLock::new(|| Mutex::new(Chosen::default()));

    /// What is known of a player's choice: `None` not looked up yet, `Some(None)` known to have none.
    pub fn cached(uuid: u128) -> Option<Option<String>> {
        CHOSEN.lock().ok()?.by_uuid.get(&uuid).cloned()
    }

    /// The attribute modifier ids this session has put on a player, `None` if it has not yet.
    pub fn applied(uuid: u128) -> Option<std::collections::BTreeSet<String>> {
        CHOSEN.lock().ok()?.applied.get(&uuid).cloned()
    }

    pub fn queue_potion(uuid: u128) {
        if let Ok(mut guard) = CHOSEN.lock() {
            guard.potions.push(uuid);
        }
    }

    /// Everyone who drank a potion since the last call.
    pub fn take_potions() -> Vec<u128> {
        CHOSEN.lock().map(|mut guard| std::mem::take(&mut guard.potions)).unwrap_or_default()
    }

    pub fn set_applied(uuid: u128, ids: std::collections::BTreeSet<String>) {
        if let Ok(mut guard) = CHOSEN.lock() {
            guard.applied.insert(uuid, ids);
        }
    }

    pub fn remember(uuid: u128, origin: Option<String>) {
        if let Ok(mut guard) = CHOSEN.lock() {
            guard.by_uuid.insert(uuid, origin);
        }
    }

    /// Ties an entity id (this session's) to the origin of the player it is, or forgets it.
    pub fn bind_entity(entity: i32, origin: Option<String>) {
        if let Ok(mut guard) = CHOSEN.lock() {
            match origin {
                Some(o) => {
                    guard.by_entity.insert(entity, o);
                }
                None => {
                    guard.by_entity.remove(&entity);
                }
            }
        }
    }

    /// The origin of the player with this entity id, when they have one.
    pub fn origin_of_entity(entity: i64) -> Option<String> {
        let id = i32::try_from(entity).ok()?;
        CHOSEN.lock().ok()?.by_entity.get(&id).cloned()
    }

    #[cfg(test)]
    mod tests {
        use super::*;

        #[test]
        fn entities_follow_their_players_choice() {
            bind_entity(7001, Some("origins:merling".to_owned()));
            assert_eq!(origin_of_entity(7001).as_deref(), Some("origins:merling"));
            bind_entity(7001, None);
            assert_eq!(origin_of_entity(7001), None);
            assert_eq!(origin_of_entity(i64::MAX), None);
        }

        #[test]
        fn a_player_with_no_origin_is_remembered_as_such() {
            assert_eq!(cached(0xfeed), None);
            remember(0xfeed, None);
            assert_eq!(cached(0xfeed), Some(None));
            remember(0xfeed, Some("origins:avian".to_owned()));
            assert_eq!(cached(0xfeed), Some(Some("origins:avian".to_owned())));
        }
    }
}

#[cfg(test)]
mod effect_power_tests {
    use super::*;

    #[test]
    fn feline_gets_night_vision_and_blazeborn_loses_poison_and_hunger() {
        assert_eq!(
            effect_commands(Some("origins:feline"), "Alex"),
            vec!["effect give Alex minecraft:night_vision 30 0 true".to_owned()]
        );
        assert_eq!(
            effect_commands(Some("origins:blazeborn"), "Alex"),
            vec![
                "effect clear Alex minecraft:poison".to_owned(),
                "effect clear Alex minecraft:hunger".to_owned()
            ]
        );
    }

    #[test]
    fn nobody_else_gets_anything() {
        assert!(effect_commands(None, "Alex").is_empty());
        assert!(effect_commands(Some("origins:human"), "Alex").is_empty());
        assert!(effect_commands(Some("origins:merling"), "Alex").is_empty());
    }

    #[test]
    fn a_name_that_could_carry_a_command_gets_nothing() {
        for name in ["", "two words", "Alex;op", "a/b", "Alex\n", "ThisNameIsFarTooLong", "Zoë"] {
            assert!(!is_plain_name(name), "{name:?}");
            assert!(effect_commands(Some("origins:feline"), name).is_empty(), "{name:?}");
        }
        assert!(is_plain_name("Alex_99"));
        assert!(is_plain_name("A"));
    }

    #[test]
    fn every_effect_power_belongs_to_an_origin_and_is_marked_implemented() {
        for (power, _, _, _) in EFFECT_POWERS {
            assert!(IMPLEMENTED_POWERS.contains(power), "{power}");
            assert!(ORIGINS.iter().any(|(_, _, powers)| powers.contains(power)), "{power}");
        }
        for (power, _) in IMMUNITY_POWERS {
            assert!(IMPLEMENTED_POWERS.contains(power), "{power}");
            assert!(ORIGINS.iter().any(|(_, _, powers)| powers.contains(power)), "{power}");
        }
    }

    #[test]
    fn due_fires_once_in_every_n_calls() {
        let hits = (0..40).filter(|_| state::due(20)).count();
        assert_eq!(hits, 2);
    }
}

#[cfg(test)]
mod attribute_power_tests {
    use super::*;
    use std::collections::BTreeSet;

    fn ids(list: &[&str]) -> BTreeSet<String> {
        list.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn first_sight_clears_every_modifier_of_ours_then_adds_the_right_ones() {
        let (commands, now) = attribute_commands(None, Some("origins:feline"), "Alex");
        assert_eq!(commands.len(), ATTRIBUTE_MODS.len() + 1);
        assert!(commands[..ATTRIBUTE_MODS.len()].iter().all(|c| c.contains("modifier remove")));
        assert_eq!(
            commands.last().unwrap(),
            "attribute Alex minecraft:max_health modifier add origins_legacy:nine_lives -2 add_value"
        );
        assert_eq!(now, ids(&["origins_legacy:nine_lives"]));
    }

    #[test]
    fn nothing_changes_nothing_is_sent() {
        let (commands, now) = attribute_commands(Some(&ids(&["origins_legacy:nine_lives"])), Some("origins:feline"), "Alex");
        assert!(commands.is_empty());
        assert_eq!(now, ids(&["origins_legacy:nine_lives"]));
    }

    #[test]
    fn a_change_of_origin_removes_the_old_modifier_and_adds_the_new() {
        let have = ids(&["origins_legacy:nine_lives"]);
        let (commands, now) = attribute_commands(Some(&have), Some("origins:shulk"), "Alex");
        assert_eq!(
            commands,
            vec![
                "attribute Alex minecraft:max_health modifier remove origins_legacy:nine_lives".to_owned(),
                "attribute Alex minecraft:armor modifier add origins_legacy:natural_armor 8 add_value".to_owned(),
            ]
        );
        assert_eq!(now, ids(&["origins_legacy:natural_armor"]));
    }

    #[test]
    fn losing_the_origin_removes_everything_and_reach_is_two_modifiers() {
        let have = ids(&["origins_legacy:extra_reach_block", "origins_legacy:extra_reach_entity"]);
        let (commands, now) = attribute_commands(Some(&have), None, "Alex");
        assert_eq!(commands.len(), 2);
        assert!(commands.iter().all(|c| c.contains("modifier remove origins_legacy:extra_reach_")));
        assert!(now.is_empty());
        let (commands, now) = attribute_commands(Some(&BTreeSet::new()), Some("origins:enderian"), "Alex");
        assert_eq!(commands.len(), 2);
        assert_eq!(now.len(), 2);
    }

    #[test]
    fn the_multiplier_uses_the_commands_word_and_a_decimal_value() {
        let (commands, _) = attribute_commands(Some(&BTreeSet::new()), Some("origins:avian"), "Alex");
        assert_eq!(
            commands,
            vec!["attribute Alex minecraft:movement_speed modifier add origins_legacy:tailwind 0.2 add_multiplied_base".to_owned()]
        );
    }

    #[test]
    fn a_name_that_could_carry_a_command_gets_nothing() {
        let (commands, _) = attribute_commands(None, Some("origins:feline"), "Alex; op Alex");
        assert!(commands.is_empty());
    }

    #[test]
    fn every_attribute_power_belongs_to_an_origin_and_is_marked_implemented() {
        for m in ATTRIBUTE_MODS {
            assert!(IMPLEMENTED_POWERS.contains(&m.power), "{}", m.power);
            assert!(ORIGINS.iter().any(|(_, _, powers)| powers.contains(&m.power)), "{}", m.power);
        }
    }
}

#[cfg(test)]
mod kinetic_damage_tests {
    use super::*;

    #[test]
    fn elytrian_takes_half_as_much_again_from_falls_and_walls() {
        assert_eq!(damage_taken_factor("origins:elytrian", "minecraft:fall"), 1.5);
        assert_eq!(damage_taken_factor("origins:elytrian", "minecraft:fly_into_wall"), 1.5);
        assert_eq!(damage_taken_factor("origins:elytrian", "minecraft:lava"), 1.0);
        assert_eq!(damage_taken_factor("origins:elytrian", "minecraft:generic"), 1.0);
    }

    #[test]
    fn nobody_else_is_changed() {
        for origin in ["origins:human", "origins:feline", "origins:avian", "origins:merling"] {
            assert_eq!(damage_taken_factor(origin, "minecraft:fall"), 1.0, "{origin}");
        }
        // Feline's fall immunity still wins: it cancels the hit before any factor applies.
        assert!(invulnerable_to("origins:feline", "minecraft:fall"));
    }
}

#[cfg(test)]
mod item_rule_tests {
    use super::*;

    #[test]
    fn arachnid_eats_only_meat_and_avian_everything_but() {
        for meat in ["minecraft:beef", "minecraft:cooked_cod", "minecraft:spider_eye", "minecraft:rotten_flesh"] {
            assert!(may_eat("origins:arachnid", meat), "{meat}");
            assert!(!may_eat("origins:avian", meat), "{meat}");
        }
        for plant in ["minecraft:bread", "minecraft:apple", "minecraft:golden_apple", "minecraft:carrot"] {
            assert!(!may_eat("origins:arachnid", plant), "{plant}");
            assert!(may_eat("origins:avian", plant), "{plant}");
        }
    }

    #[test]
    fn nobody_else_has_a_diet() {
        for origin in ["origins:human", "origins:feline", "origins:shulk", "origins:merling"] {
            assert!(may_eat(origin, "minecraft:beef") && may_eat(origin, "minecraft:bread"), "{origin}");
        }
    }

    #[test]
    fn shulk_will_not_raise_a_shield() {
        assert!(!may_use("origins:shulk", "minecraft:shield"));
        assert!(may_use("origins:shulk", "minecraft:bow"));
        assert!(may_use("origins:human", "minecraft:shield"));
        assert!(may_use("origins:arachnid", "minecraft:shield"));
    }

    #[test]
    fn potion_damage_is_a_plain_command() {
        assert_eq!(potion_damage_command("Alex").as_deref(), Some("damage Alex 2 minecraft:magic"));
        assert_eq!(potion_damage_command("Alex 1"), None);
        assert_eq!(potion_damage_command(""), None);
    }

    #[test]
    fn a_potion_is_queued_once_and_taken_once() {
        let uuid = 0xFEED_0000_0000_0000_0000_0000_0000_0007_u128;
        state::queue_potion(uuid);
        assert!(state::take_potions().contains(&uuid));
        assert!(!state::take_potions().contains(&uuid));
    }

    #[test]
    fn every_item_rule_power_belongs_to_an_origin_and_is_marked_implemented() {
        for power in ["damage_from_potions", "carnivore", "vegetarian", "no_shield"] {
            assert!(IMPLEMENTED_POWERS.contains(&power), "{power}");
            assert!(ORIGINS.iter().any(|(_, _, powers)| powers.contains(&power)), "{power}");
        }
    }
}

#[cfg(test)]
mod slow_falling_tests {
    use super::*;

    #[test]
    fn avian_floats_down_and_only_avian() {
        assert_eq!(
            effect_commands(Some("origins:avian"), "Alex"),
            vec!["effect give Alex minecraft:slow_falling 5 0 true".to_owned()]
        );
        for origin in ["origins:human", "origins:elytrian", "origins:shulk", "origins:phantom"] {
            assert!(effect_commands(Some(origin), "Alex").is_empty(), "{origin}");
        }
    }
}
