// `/origin get|list|powers|set <origin>`, offered to every player's chat box (usages and levels: COMMAND_USAGES).
fn origins_legacy_register_commands(commands: &mut Vec<horizon_client::mod_api::NativeCommand>) {
    use horizon_core::noise::port_origins_legacy_core as oc;
    for (usage, level) in oc::COMMAND_USAGES {
        commands.push(horizon_client::mod_api::NativeCommand::op(usage, *level));
    }
}
