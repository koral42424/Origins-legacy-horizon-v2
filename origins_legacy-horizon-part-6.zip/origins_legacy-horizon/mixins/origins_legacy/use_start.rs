// A player starts using an item: Shulk (no_shield) will not raise a shield.
fn origins_legacy_use_start(game: &crate::game::Game<'_>, entity: Option<i32>, stack: &ItemStack, canceled: &mut bool) {
    crate::game::port_origins_legacy_game::on_use_start(game, entity, &stack.item, canceled);
}
