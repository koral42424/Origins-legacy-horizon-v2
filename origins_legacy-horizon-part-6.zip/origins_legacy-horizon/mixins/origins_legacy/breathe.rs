// Merling's `water_breathing`: the air logic turned round (the Java WaterBreathingMixin).
// Runs where the game asks each player how they breathe, with only the entity id to go by.
fn origins_legacy_breathe(entity: u32, kind: &str, can_breathe: &mut bool) {
    use horizon_core::noise::port_origins_legacy_core as oc;
    if kind != "minecraft:player" {
        return;
    }
    if let Some(origin) = oc::state::origin_of_entity(i64::from(entity)) {
        *can_breathe = oc::can_breathe(&origin, *can_breathe);
    }
}
