// A player finished using an item: a potion drunk by an Enderian is queued for the server's tick (damage_from_potions).
fn origins_legacy_item_finished(game: &mut crate::game::Game<'_>, stack: &ItemStack) {
    crate::game::port_origins_legacy_game::on_item_finished(game, &stack.item);
}
