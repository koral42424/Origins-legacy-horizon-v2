# Horizon patches for Origins: Legacy

Changes to Horizon itself that the mod needs. Apply to a Horizon checkout with `git apply`, or skip them if your
Horizon already has the same fix.

## 0001-attribute-command-reaches-guests.patch

`/attribute` handled the host's own player and mobs, and answered `commands.attribute.failed.entity` for every
other player, so the attribute powers (fragile, nine_lives, natural_armor, tailwind, extra_reach) did nothing for
the guests of a hosted world or a dedicated server. The patch runs the player's own branch under `for_player`
(the guest's state swapped in), the way `/effect` does. 12 lines added to
`crates/horizon-client/src/game/commands/world_cmds.rs`, none removed.

Upstream has a pull request that does the same through `for_player`: horizon-rust/horizon #11709 ("Route attribute
commands through the selected guest body"). If it is merged in your checkout, `cmd_attribute` already routes
`Target::Guest` and you do not need this patch.

Not compiled or tested. Whether a guest's client takes the synced modifiers (speed, reach) has not been checked in a
real two-player session.
