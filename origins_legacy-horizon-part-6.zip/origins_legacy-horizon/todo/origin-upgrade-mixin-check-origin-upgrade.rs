// Not ported yet: the Java @Inject(INVOKE) on PlayerAdvancements.award (OriginUpgradeMixin.checkOriginUpgrade).
// Why it's off: `horizon_client::game::advancements::Game<'_>::award` has a closure in its body: horizon-mixins doesn't rewrite such bodies with BEFORE_CALL. A HEAD hook on it, or a BEFORE_CALL on a function it calls, may work instead.
// horizon-mixins kind: BEFORE_CALL on `horizon_client::game::advancements::Game<'_>::award`
// Note: Only whole statements, plain let initializers and block tails can be selected.
// Note: The call it hooks (PlayerAdvancements.unregisterListeners) isn't mapped to a Rust function yet.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   ChatFormatting.GOLD -> (not mapped yet)
//   AdvancementProgress.isDone -> (not mapped yet)
//   Component.translatable -> (not mapped yet)
//   MutableComponent.withStyle -> horizon_client_core::text::Text::with_style (suggested, high)
//   Identifier.toString -> (not mapped yet)
//   PlayerAdvancements.award -> horizon_client::game::advancements::Game<'_>::award (suggested, high)
//   PlayerAdvancements.unregisterListeners -> (not mapped yet)
//   ServerPlayer.sendSystemMessage -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/OriginUpgradeMixin.java:28:
// | @Inject(
// |    method = "award",
// |    at = @At(value = "INVOKE", target = "Lnet/minecraft/server/PlayerAdvancements;unregisterListeners(Lnet/minecraft/advancements/AdvancementHolder;)V"),
// |    locals = LocalCapture.CAPTURE_FAILHARD
// | )
// | private void checkOriginUpgrade(
// |    AdvancementHolder advancement, String criterionKey, CallbackInfoReturnable<Boolean> cir, boolean bl, AdvancementProgress advancementProgress, boolean bl2
// | ) {
// |    if (advancementProgress.isDone()) {
// |       Origin.get(this.player)
// |          .forEach(
// |             (layer, o) -> {
// |                Optional<OriginUpgrade> upgrade = o.getUpgrade(advancement);
// |                if (upgrade.isPresent()) {
// |                   try {
// |                      Origin upgradeTo = OriginRegistry.get(upgrade.get().getUpgradeToOrigin());
// |                      if (upgradeTo != null) {
// |                         OriginComponent component = (OriginComponent)ModComponents.ORIGIN.get(this.player);
// |                         component.setOrigin(layer, upgradeTo);
// |                         component.sync();
// |                         String announcement = upgrade.get().getAnnouncement();
// |                         if (!announcement.isEmpty()) {
// |                            this.player.sendSystemMessage(Component.translatable(announcement).withStyle(ChatFormatting.GOLD), false);
// |                         }
// |                      }
// |                   } catch (IllegalArgumentException e) {
// |                      Origins.LOGGER
// |                         .error(
// |                            "Could not perform Origins upgrade from "
// |                               + o.getIdentifier().toString()
// |                               + " to "
// |                               + upgrade.get().getUpgradeToOrigin().toString()
// |                               + ", as the upgrade origin did not exist!"
// |                         );
// |                   }
// |                }
// |             }
// |          );
// |    }
// | }
