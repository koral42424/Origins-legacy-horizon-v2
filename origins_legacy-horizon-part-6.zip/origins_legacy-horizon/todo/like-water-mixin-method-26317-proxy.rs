// Not ported yet: the Java @WrapOperation(INVOKE) on LivingEntity.travelInWater (LikeWaterMixin.method_26317Proxy).
// Why it's off: No Horizon function mapped for LivingEntity.travelInWater (run `match`, or map it in a --mappings file).
// horizon-mixins kind: WRAP_OPERATION
// Note: No Horizon function known for LivingEntity.travelInWater: run `match`.
// Note: The call it hooks (LivingEntity.getFluidFallingAdjustedMovement) isn't mapped to a Rust function yet.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   Entity.<init> -> (not mapped yet)
//   LivingEntity.getFluidFallingAdjustedMovement -> (not mapped yet)
//   LivingEntity.travelInWater -> (not mapped yet)
//   Vec3.<init> -> (not mapped yet)
//   Vec3.x -> (not mapped yet)
//   Vec3.y -> (not mapped yet)
//   Vec3.z -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/LikeWaterMixin.java:20:
// | @WrapOperation(
// |    method = "travelInWater",
// |    at = @At(
// |       value = "INVOKE",
// |       target = "Lnet/minecraft/world/entity/LivingEntity;getFluidFallingAdjustedMovement(DZLnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;"
// |    )
// | )
// | public Vec3 method_26317Proxy(LivingEntity instance, double gravity, boolean isFalling, Vec3 deltaMovement, Operation<Vec3> original) {
// |    Vec3 oldReturn = (Vec3)original.call(new Object[]{instance, gravity, isFalling, deltaMovement});
// |    return OriginsPowerTypes.LIKE_WATER.isActive(this) && Math.abs(deltaMovement.y - gravity / 16.0) < 0.025
// |       ? new Vec3(oldReturn.x, 0.0, oldReturn.z)
// |       : oldReturn;
// | }
