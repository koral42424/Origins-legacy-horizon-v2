// Not ported yet: the Java @Inject(RETURN) on ArgumentTypeInfos.bootstrap (ArgumentTypesMixin.registerApoliArgumentTypes).
// Why it's off: No Horizon function mapped for ArgumentTypeInfos.bootstrap (run `match`, or map it in a --mappings file).
// horizon-mixins kind: RETURN
// Note: Horizon's RETURN runs at every normal exit and passes the return value on.
// Note: No Horizon function known for ArgumentTypeInfos.bootstrap: run `match`.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   ArgumentTypeInfos.bootstrap -> (not mapped yet)
//   SingletonArgumentInfo.contextFree -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/ArgumentTypesMixin.java:26:
// | @Inject(method = "bootstrap", at = @At("RETURN"))
// | private static void registerApoliArgumentTypes(Registry<ArgumentTypeInfo<?, ?>> registry, CallbackInfoReturnable<ArgumentTypeInfo<?, ?>> cir) {
// |    register(registry, "origins:origin", OriginArgumentType.class, SingletonArgumentInfo.contextFree(OriginArgumentType::origin));
// |    register(registry, "origins:layer", LayerArgumentType.class, SingletonArgumentInfo.contextFree(LayerArgumentType::layer));
// | }
