// Not ported yet: the Java @Inject(TAIL) on PlayerList.placeNewPlayer (LoginMixin.openOriginsGui).
// Why it's off: `horizon_client::lan::hub::Hub::place_new_player` has a closure in its body: horizon-mixins doesn't rewrite such bodies with RETURN. A HEAD hook on it, or a RETURN on a function it calls, may work instead.
// horizon-mixins kind: RETURN on `horizon_client::lan::hub::Hub::place_new_player`
// Note: Horizon has no TAIL: RETURN runs at every exit, early ones too.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   PlayerList.placeNewPlayer -> horizon_client::lan::hub::Hub::place_new_player (suggested, high)
//
// Decompiled Java, io/github/apace100/origins/mixin/LoginMixin.java:36:
// | @Inject(at = @At("TAIL"), method = "placeNewPlayer")
// | private void openOriginsGui(Connection connection, ServerPlayer player, CommonListenerCookie cookie, CallbackInfo ci) {
// |    OriginComponent component = (OriginComponent)ModComponents.ORIGIN.get(player);
// |    HashMap<Identifier, Origin> origins = new HashMap<>(OriginRegistry.get());
// |    origins.remove(Origin.EMPTY.getIdentifier());
// |    ServerPlayNetworking.send(player, new PowersAndOriginsPacket(new PowerListPacket(PowerTypeRegistry.get()), OriginListPacket.fromOriginsMap(origins)));
// |    ServerPlayNetworking.send(player, new LayerListPacket(OriginLayers.getLayers().stream().map(layer -> {
// |       if (layer.isEnabled() && !component.hasOrigin(layer)) {
// |          component.setOrigin(layer, Origin.EMPTY);
// |       }
// |
// |       return (OriginLayer)layer;
// |    }).toList()));
// |    BadgeManager.sync(player);
// |    List<ServerPlayer> playerList = this.getPlayers();
// |    playerList.forEach(spe -> ModComponents.ORIGIN.syncWith(spe, (ComponentProvider)player));
// |    OriginComponent.sync(player);
// |    if (!component.hasAllOrigins()) {
// |       if (component.checkAutoChoosingLayers(player, true)) {
// |          component.sync();
// |       }
// |
// |       if (component.hasAllOrigins()) {
// |          OriginComponent.onChosen(player, false);
// |       } else {
// |          ServerPlayNetworking.send(player, new OpenOriginScreenPacket(true));
// |       }
// |    }
// | }
