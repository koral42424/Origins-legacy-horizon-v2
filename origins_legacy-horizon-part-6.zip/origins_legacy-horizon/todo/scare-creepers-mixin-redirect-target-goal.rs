// Not ported yet: the Java @ModifyArg(INVOKE) on Creeper.registerGoals (ScareCreepersMixin.redirectTargetGoal).
// Why it's off: No Horizon function mapped for Creeper.registerGoals (run `match`, or map it in a --mappings file).
// horizon-mixins kind: MODIFY_ARG
// Note: No Horizon function known for Creeper.registerGoals: run `match`.
// Note: The call it hooks (GoalSelector.addGoal) isn't mapped to a Rust function yet.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   EntitySelector.NO_CREATIVE_OR_SPECTATOR -> (not mapped yet)
//   AvoidEntityGoal.<init> -> (not mapped yet)
//   GoalSelector.addGoal -> (not mapped yet)
//   NearestAttackableTargetGoal.<init> -> (not mapped yet)
//   Creeper.registerGoals -> (not mapped yet)
//   Monster.<init> -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/ScareCreepersMixin.java:33:
// | @ModifyArg(
// |    at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V", ordinal = 8),
// |    method = "registerGoals"
// | )
// | private Goal redirectTargetGoal(Goal original) {
// |    return new NearestAttackableTargetGoal(this, Player.class, 10, true, false, (e, l) -> !OriginsPowerTypes.SCARE_CREEPERS.isActive(e));
// | }
