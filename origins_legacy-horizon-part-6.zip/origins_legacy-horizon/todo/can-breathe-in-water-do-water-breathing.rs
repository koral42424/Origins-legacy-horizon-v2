// Not ported yet: the Java @Inject(HEAD) on LivingEntity.canBreatheUnderwater (CanBreatheInWater.doWaterBreathing).
// Why it's off: No Horizon function mapped for LivingEntity.canBreatheUnderwater (run `match`, or map it in a --mappings file).
// horizon-mixins kind: HEAD
// Note: No Horizon function known for LivingEntity.canBreatheUnderwater: run `match`.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   Entity.<init> -> (not mapped yet)
//   LivingEntity.canBreatheUnderwater -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/WaterBreathingMixin.java:28:
// | @Inject(at = @At("HEAD"), method = "canBreatheUnderwater", cancellable = true)
// | public void doWaterBreathing(CallbackInfoReturnable<Boolean> info) {
// |    if (OriginsPowerTypes.WATER_BREATHING.isActive(this)) {
// |       info.setReturnValue(true);
// |    }
// | }
