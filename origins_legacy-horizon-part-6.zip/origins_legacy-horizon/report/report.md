# Horizon port report: Origins: Legacy

`origins-legacy` 1.12.20+26.3 · Origins-Legacy-1.12.20+26.3.jar · 92 classes

**Partly convertible**

| Status | Count | Meaning |
|---|---|---|
| auto | 9 | The Horizon hook or injection is known: the wiring can be generated. The Java body still has to become Rust. |
| content | 8 | Data and assets: horizon-port-pack carries these into a content mod (.hmod). |
| needs-mapping | 9 | The kind of change carries over, but the matching Horizon function isn't in the table yet. Run `match`. |
| needs-translation | 8 | No direct equivalent: a person (or an AI agent) has to rewrite this part. |
| unsupported | 8 | Horizon has nothing this can attach to yet. |

## Entry points

- `main`: io.github.apace100.origins.Origins
- `client`: io.github.apace100.origins.OriginsClient
- `modmenu`: io.github.apace100.origins.integration.ModMenuIntegration
- `cardinal-components-entity`: io.github.apace100.origins.registry.ModComponents
- `calio:ordered-resource-listener`: io.github.apace100.origins.Origins

## Fabric events

| Event | In | Horizon | Status | Note |
|---|---|---|---|---|
| CommandRegistrationCallback.EVENT | `Origins` | hook `command` | needs-translation | Server commands. Horizon's command hook is client-side. |
| EntityRendererRegistry.register | `OriginsClient` | – | unsupported | Custom entity renderers aren't supported. |
| KeyMappingHelper.registerKeyMapping | `OriginsClient` | hook `key` | auto | Mojang-named variant of KeyBindingHelper. |
| ClientTickEvents.START_CLIENT_TICK | `OriginsClient` | hook `tick` | auto | START and END of the tick both land on Horizon's one tick hook. |
| ServerPlayNetworking.send | `BadgeManager` | – | unsupported | Custom packets aren't supported. |
| PayloadTypeRegistry.clientboundPlay | `ModPackets` | – | unsupported | Horizon speaks the vanilla protocol; custom packets aren't supported. |
| PayloadTypeRegistry.register | `ModPackets` | – | unsupported | Horizon speaks the vanilla protocol; custom packets aren't supported. |
| PayloadTypeRegistry.serverboundPlay | `ModPackets` | – | unsupported | Horizon speaks the vanilla protocol; custom packets aren't supported. |
| ServerPlayNetworking.registerGlobalReceiver | `ModPacketsC2S` | – | unsupported | Custom packets aren't supported. |
| ClientPlayConnectionEvents.INIT | `ModPacketsS2C` | hook `tick` | auto | JOIN runs on the window's first tick with a player after none; DISCONNECT isn't mapped. |
| ClientPlayNetworking.registerReceiver | `ModPacketsS2C` | – | unsupported | Custom packets aren't supported. |
| ClientPlayNetworking.send | `ChooseOriginScreen` | – | unsupported | Custom packets aren't supported. |
| ServerTickEvents.END_SERVER_TICK | `Scheduler` | hook `tick` | auto | The tick hook runs in every Game, the server's too: run server logic only when `!self.native_window()`. |

## Mixins

| Injection | In | Horizon | Status | Note |
|---|---|---|---|---|
| @Inject(RETURN) on ArgumentTypeInfos.bootstrap | `ArgumentTypesMixin.registerApoliArgumentTypes` | RETURN | needs-mapping | Horizon's RETURN runs at every normal exit and passes the return value on. No Horizon function known for ArgumentTypeInfos.bootstrap: run `match`. |
| @WrapOperation(INVOKE) on ConduitBlockEntity.applyEffects at Lnet/minecraft/world/entity/player/Player;isInWaterOrRain()Z | `ConduitOnLandMixin.allowConduitPowerOnLand` | WRAP_OPERATION | needs-mapping | No Horizon function known for ConduitBlockEntity.applyEffects: run `match`. The call it hooks (Player.isInWaterOrRain) isn't mapped to a Rust function yet. |
| mixin into Window with no injectors (interfaces or @Shadow only) | `DebugContextMixin` | – | needs-translation | Usually adds an interface or fields to a game class: needs a manual change. |
| @WrapOperation(INVOKE) on LivingEntity.travelInWater at Lnet/minecraft/world/entity/LivingEntity;getFluidFallingAdjustedMovement(DZLnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; | `LikeWaterMixin.method_26317Proxy` | WRAP_OPERATION | needs-mapping | No Horizon function known for LivingEntity.travelInWater: run `match`. The call it hooks (LivingEntity.getFluidFallingAdjustedMovement) isn't mapped to a Rust function yet. |
| @Inject(TAIL) on PlayerList.placeNewPlayer | `LoginMixin.openOriginsGui` | RETURN on horizon_client::lan::hub::Hub::place_new_player | auto | Horizon has no TAIL: RETURN runs at every exit, early ones too. |
| @Inject(HEAD) on Player.makeStuckInBlock | `NoCobwebSlowdownMixin.slowMovement` | HEAD on horizon_client::motion::MotionWorld<'_, '_, '_>::make_stuck_in_block | auto |  |
| @Inject(INVOKE) on PlayerAdvancements.award at Lnet/minecraft/server/PlayerAdvancements;unregisterListeners(Lnet/minecraft/advancements/AdvancementHolder;)V | `OriginUpgradeMixin.checkOriginUpgrade` | BEFORE_CALL on horizon_client::game::advancements::Game<'_>::award | needs-mapping | Only whole statements, plain let initializers and block tails can be selected. The call it hooks (PlayerAdvancements.unregisterListeners) isn't mapped to a Rust function yet. |
| @Inject(TAIL) on Creeper.registerGoals | `ScareCreepersMixin.addGoals` | RETURN | needs-mapping | Horizon has no TAIL: RETURN runs at every exit, early ones too. No Horizon function known for Creeper.registerGoals: run `match`. |
| @ModifyArg(INVOKE) on Creeper.registerGoals at Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V | `ScareCreepersMixin.redirectTargetGoal` | MODIFY_ARG | needs-mapping | No Horizon function known for Creeper.registerGoals: run `match`. The call it hooks (GoalSelector.addGoal) isn't mapped to a Rust function yet. |
| @Inject(HEAD) on Entity.isInvulnerableToBase | `SelectionInvulnerabilityMixin.makeOriginInvulnerable` | HEAD | needs-mapping | No Horizon function known for Entity.isInvulnerableToBase: run `match`. |
| @Inject(HEAD) on ConnectScreen.connect | `ServerCheckMixin.resetServerOriginsState` | HEAD | needs-mapping | No Horizon function known for ConnectScreen.connect: run `match`. |
| @Inject(HEAD) on LivingEntity.canBreatheUnderwater | `WaterBreathingMixin$CanBreatheInWater.doWaterBreathing` | HEAD | needs-mapping | No Horizon function known for LivingEntity.canBreatheUnderwater: run `match`. |
| @Inject(TAIL) on Player.tick | `WaterBreathingMixin$UpdateAir.tick` | RETURN on horizon_client::attack_strength::AttackStrength::tick | auto | Horizon has no TAIL: RETURN runs at every exit, early ones too. |
| @ModifyExpressionValue(INVOKE) on Player.tick at Lnet/minecraft/world/entity/player/Player;isEyeInFluid(Lnet/minecraft/tags/TagKey;)Z | `WaterBreathingMixin$UpdateAir.isSubmergedInProxy` | MODIFY_EXPRESSION_VALUE on horizon_client::attack_strength::AttackStrength::tick | auto | Selects an exact Rust expression: pick it in the target function. |
| @Inject(HEAD) on LocalPlayer.getWaterVision | `WaterVisibilityMixin.getUnderwaterVisibility` | HEAD on horizon_client_render::fog::FogState::water_vision | auto |  |

## Classes extending the game

| Class | In | Status | Note |
|---|---|---|---|
| extends Item | `OrbOfOriginItem` | needs-translation | Overrides use, appendHoverText, getTargets: the content ports, that behaviour needs native code. |
| extends WebBlock | `TemporaryCobwebBlock` | needs-translation | No mapping for this superclass yet. |
| extends ThrowableItemProjectile | `EnderianPearlEntity` | needs-translation | No mapping for this superclass yet. |
| extends Screen | `OriginDisplayScreen` | needs-translation | No general screen hook; simple option pages can use the settings hook. |
| extends Screen | `WaitForNextLayerScreen` | needs-translation | No general screen hook; simple option pages can use the settings hook. |
| extends SimpleCriterionTrigger | `ChoseOriginCriterion` | needs-translation | No mapping for this superclass yet. |

## Content

| What | In | Status | Note |
|---|---|---|---|
| registers blocks or items in code | `Origins` | content | Registration and properties: horizon-port-pack carries them as a content mod. |
| registers blocks or items in code | `OriginsEntityConditions` | content | Registration and properties: horizon-port-pack carries them as a content mod. |
| registers blocks or items in code | `OriginsPowerTypes` | content | Registration and properties: horizon-port-pack carries them as a content mod. |
| registers blocks or items in code | `ModBlocks` | content | Registration and properties: horizon-port-pack carries them as a content mod. |
| registers blocks or items in code | `ModEntities` | content | Registration and properties: horizon-port-pack carries them as a content mod. |
| registers blocks or items in code | `ModItems` | content | Registration and properties: horizon-port-pack carries them as a content mod. |
| registers blocks or items in code | `ModLoot` | content | Registration and properties: horizon-port-pack carries them as a content mod. |
| 45 asset files, 87 data files | `jar resources` | content | Recipes, loot, tags, models, textures, worldgen: horizon-port-pack carries these. |

## Game methods and fields used

31 of 317 are mapped to Horizon. Every Java body that uses an unmapped one needs it mapped before its Rust can be written.

<details><summary>Mapped</summary>

| Java | Horizon |
|---|---|
| `net/minecraft/client/KeyMapping#<init>` | `self.native_mod_key(MOD_ID, name, default)` |
| `net/minecraft/client/KeyMapping#consumeClick` | `key == self.native_mod_key(..) && pressed, in the key hook` |
| `net/minecraft/client/Minecraft#getInstance` | `self` |
| `net/minecraft/client/Minecraft#player` | `self.native_player()` |
| `net/minecraft/client/gui/Font#split` | horizon_client_render::font::Font::split_formatted (suggested) |
| `net/minecraft/client/gui/Font#width` | `self.native_text_width(text)` |
| `net/minecraft/client/gui/GuiGraphicsExtractor#itemDecorations` | horizon_client_render::hud_overlays::item_decorations (suggested) |
| `net/minecraft/client/gui/screens/Screen#extractBackground` | horizon_client::game::screens::Screen::blurs_background (suggested) |
| `net/minecraft/client/player/LocalPlayer#getWaterVision` | horizon_client_render::fog::FogState::water_vision (suggested) |
| `net/minecraft/core/Registry#register` | content |
| `net/minecraft/core/registries/BuiltInRegistries#BLOCK` | content |
| `net/minecraft/core/registries/BuiltInRegistries#ITEM` | content |
| `net/minecraft/network/chat/MutableComponent#append` | horizon_client::game::dedicated::append (suggested) |
| `net/minecraft/network/chat/MutableComponent#withStyle` | horizon_client_core::text::Text::with_style (suggested) |
| `net/minecraft/network/codec/ByteBufCodecs#list` | horizon_protocol::item::skip::list (suggested) |
| `net/minecraft/network/codec/ByteBufCodecs#optional` | horizon_protocol::item::skip::optional (suggested) |
| `net/minecraft/server/PlayerAdvancements#award` | horizon_client::game::advancements::Game<'_>::award (suggested) |
| `net/minecraft/server/level/ServerLevel#isClientSide` | horizon_world::level::is_client_side (suggested) |
| `net/minecraft/server/level/ServerPlayer#getDisplayName` | horizon_client::lan::hub::display_name (suggested) |
| `net/minecraft/server/players/PlayerList#placeNewPlayer` | horizon_client::lan::hub::Hub::place_new_player (suggested) |
| `net/minecraft/util/Mth#floor` | horizon_client_render::gfx::occlusion::floor (suggested) |
| `net/minecraft/world/entity/Entity#stopRiding` | horizon_client::lan::guest::Guest::stop_riding (suggested) |
| `net/minecraft/world/entity/player/Player#getDisplayName` | horizon_client::lan::hub::display_name (suggested) |
| `net/minecraft/world/entity/player/Player#makeStuckInBlock` | horizon_client::motion::MotionWorld<'_, '_, '_>::make_stuck_in_block (suggested) |
| `net/minecraft/world/entity/player/Player#tick` | horizon_client::attack_strength::AttackStrength::tick (suggested) |
| `net/minecraft/world/item/Item#<init>` | content |
| `net/minecraft/world/item/Item$Properties#stacksTo` | content |
| `net/minecraft/world/item/ItemStack#shrink` | horizon_client::game::dispenser::shrink (suggested) |
| `net/minecraft/world/item/crafting/Recipe#assemble` | horizon_client::crafting::Special::assemble (suggested) |
| `net/minecraft/world/level/Level#isClientSide` | horizon_world::level::is_client_side (suggested) |
| `net/minecraft/world/level/Level#scheduleTick` | horizon_world::level::Behaviours::schedule_tick (suggested) |

</details>

<details><summary>Not mapped yet</summary>

| Java | Kind | Classes using it |
|---|---|---|
| `com/mojang/blaze3d/platform/InputConstants#UNKNOWN` | field | 1 |
| `com/mojang/blaze3d/platform/InputConstants$Key#getValue` | method | 1 |
| `com/mojang/blaze3d/platform/InputConstants$Type#KEYBOARD` | field | 1 |
| `net/minecraft/ChatFormatting#GOLD` | field | 1 |
| `net/minecraft/ChatFormatting#GRAY` | field | 2 |
| `net/minecraft/ChatFormatting#GREEN` | field | 1 |
| `net/minecraft/ChatFormatting#RED` | field | 1 |
| `net/minecraft/ChatFormatting#UNDERLINE` | field | 1 |
| `net/minecraft/ChatFormatting#YELLOW` | field | 1 |
| `net/minecraft/advancements/AdvancementHolder#id` | method | 1 |
| `net/minecraft/advancements/AdvancementProgress#isDone` | method | 1 |
| `net/minecraft/advancements/triggers/SimpleCriterionTrigger#<init>` | method | 1 |
| `net/minecraft/client/KeyMapping#createNameSupplier` | method | 1 |
| `net/minecraft/client/KeyMapping$Category#register` | method | 1 |
| `net/minecraft/client/Minecraft#execute` | method | 1 |
| `net/minecraft/client/Minecraft#gui` | field | 5 |
| `net/minecraft/client/Minecraft#level` | field | 1 |
| `net/minecraft/client/Minecraft#options` | field | 1 |
| `net/minecraft/client/Options#advancedItemTooltips` | field | 1 |
| `net/minecraft/client/gui/Font#substrByWidth` | method | 1 |
| `net/minecraft/client/gui/Gui#screen` | method | 2 |
| `net/minecraft/client/gui/Gui#setScreen` | method | 5 |
| `net/minecraft/client/gui/GuiGraphicsExtractor#blit` | method | 3 |
| `net/minecraft/client/gui/GuiGraphicsExtractor#centeredText` | method | 2 |
| `net/minecraft/client/gui/GuiGraphicsExtractor#item` | method | 2 |
| `net/minecraft/client/gui/GuiGraphicsExtractor#pose` | method | 1 |
| `net/minecraft/client/gui/GuiGraphicsExtractor#setTooltipForNextFrame` | method | 1 |
| `net/minecraft/client/gui/GuiGraphicsExtractor#text` | method | 2 |
| `net/minecraft/client/gui/GuiGraphicsExtractor#tooltip` | method | 1 |
| `net/minecraft/client/gui/components/Button#active` | field | 1 |
| `net/minecraft/client/gui/components/Button#builder` | method | 2 |
| `net/minecraft/client/gui/components/Button#visible` | field | 1 |
| `net/minecraft/client/gui/components/Button$Builder#bounds` | method | 2 |
| `net/minecraft/client/gui/components/Button$Builder#build` | method | 2 |
| `net/minecraft/client/gui/screens/ConnectScreen#connect` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#<init>` | method | 2 |
| `net/minecraft/client/gui/screens/Screen#extractMenuBackground` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#extractRenderState` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#extractTransparentBackground` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#init` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#mouseClicked` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#mouseDragged` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#mouseReleased` | method | 1 |
| `net/minecraft/client/gui/screens/Screen#mouseScrolled` | method | 1 |
| `net/minecraft/client/gui/screens/inventory/tooltip/ClientTextTooltip#<init>` | method | 2 |
| `net/minecraft/client/gui/screens/inventory/tooltip/DefaultTooltipPositioner#INSTANCE` | field | 1 |
| `net/minecraft/client/input/MouseButtonEvent#x` | method | 1 |
| `net/minecraft/client/input/MouseButtonEvent#y` | method | 1 |
| `net/minecraft/client/multiplayer/ClientLevel#registryAccess` | method | 1 |
| `net/minecraft/client/player/AbstractClientPlayer#<init>` | method | 1 |
| `net/minecraft/client/renderer/RenderPipelines#GUI_TEXTURED` | field | 2 |
| `net/minecraft/client/renderer/entity/ThrownItemRenderer#<init>` | method | 1 |
| `net/minecraft/commands/CommandSourceStack#getPlayerOrException` | method | 1 |
| `net/minecraft/commands/CommandSourceStack#permissions` | method | 1 |
| `net/minecraft/commands/CommandSourceStack#sendFailure` | method | 1 |
| `net/minecraft/commands/CommandSourceStack#sendSuccess` | method | 1 |
| `net/minecraft/commands/Commands#argument` | method | 1 |
| `net/minecraft/commands/Commands#literal` | method | 1 |
| `net/minecraft/commands/SharedSuggestionProvider#suggestResource` | method | 2 |
| `net/minecraft/commands/arguments/EntityArgument#getPlayer` | method | 1 |
| `net/minecraft/commands/arguments/EntityArgument#getPlayers` | method | 1 |
| `net/minecraft/commands/arguments/EntityArgument#player` | method | 1 |
| `net/minecraft/commands/arguments/EntityArgument#players` | method | 1 |
| `net/minecraft/commands/synchronization/ArgumentTypeInfos#bootstrap` | method | 1 |
| `net/minecraft/commands/synchronization/SingletonArgumentInfo#contextFree` | method | 1 |
| `net/minecraft/core/BlockPos#containing` | method | 1 |
| `net/minecraft/core/Holder#value` | method | 1 |
| `net/minecraft/core/HolderLookup$Provider#lookupOrThrow` | method | 2 |
| `net/minecraft/core/HolderLookup$RegistryLookup#getOrThrow` | method | 2 |
| `net/minecraft/core/NonNullList#get` | method | 1 |
| `net/minecraft/core/NonNullList#set` | method | 1 |
| `net/minecraft/core/NonNullList#withSize` | method | 1 |
| `net/minecraft/core/Registry#addAlias` | method | 1 |
| `net/minecraft/core/component/DataComponentType#builder` | method | 1 |
| `net/minecraft/core/component/DataComponentType$Builder#build` | method | 1 |
| `net/minecraft/core/component/DataComponentType$Builder#networkSynchronized` | method | 1 |
| `net/minecraft/core/component/DataComponentType$Builder#persistent` | method | 1 |
| `net/minecraft/core/component/DataComponents#PROFILE` | field | 2 |
| `net/minecraft/core/particles/ParticleTypes#BUBBLE` | field | 1 |
| `net/minecraft/core/particles/ParticleTypes#PORTAL` | field | 1 |
| `net/minecraft/core/registries/BuiltInRegistries#DATA_COMPONENT_TYPE` | field | 1 |
| `net/minecraft/core/registries/BuiltInRegistries#ENTITY_TYPE` | field | 1 |
| `net/minecraft/core/registries/BuiltInRegistries#LOOT_CONDITION_TYPE` | field | 1 |
| `net/minecraft/core/registries/BuiltInRegistries#TRIGGER_TYPES` | field | 1 |
| `net/minecraft/core/registries/Registries#BLOCK` | field | 2 |
| `net/minecraft/core/registries/Registries#DAMAGE_TYPE` | field | 1 |
| `net/minecraft/core/registries/Registries#ENCHANTMENT` | field | 2 |
| `net/minecraft/core/registries/Registries#ENTITY_TYPE` | field | 1 |
| `net/minecraft/core/registries/Registries#ITEM` | field | 2 |
| `net/minecraft/locale/Language#getInstance` | method | 1 |
| `net/minecraft/locale/Language#getVisualOrder` | method | 1 |
| `net/minecraft/network/FriendlyByteBuf#readIdentifier` | method | 1 |
| `net/minecraft/network/FriendlyByteBuf#readInt` | method | 1 |
| `net/minecraft/network/FriendlyByteBuf#readUtf` | method | 1 |
| `net/minecraft/network/FriendlyByteBuf#writeIdentifier` | method | 3 |
| `net/minecraft/network/FriendlyByteBuf#writeInt` | method | 1 |
| `net/minecraft/network/FriendlyByteBuf#writeUtf` | method | 1 |
| `net/minecraft/network/RegistryFriendlyByteBuf#readBoolean` | method | 2 |
| `net/minecraft/network/RegistryFriendlyByteBuf#readIdentifier` | method | 2 |
| `net/minecraft/network/RegistryFriendlyByteBuf#readInt` | method | 2 |
| `net/minecraft/network/RegistryFriendlyByteBuf#readUtf` | method | 2 |
| `net/minecraft/network/RegistryFriendlyByteBuf#writeBoolean` | method | 2 |
| `net/minecraft/network/RegistryFriendlyByteBuf#writeIdentifier` | method | 2 |
| `net/minecraft/network/RegistryFriendlyByteBuf#writeInt` | method | 2 |
| `net/minecraft/network/RegistryFriendlyByteBuf#writeUtf` | method | 1 |
| `net/minecraft/network/chat/Component#empty` | method | 2 |
| `net/minecraft/network/chat/Component#getContents` | method | 2 |
| `net/minecraft/network/chat/Component#getString` | method | 2 |
| `net/minecraft/network/chat/Component#getVisualOrderText` | method | 2 |
| `net/minecraft/network/chat/Component#nullToEmpty` | method | 5 |
| `net/minecraft/network/chat/Component#translatable` | method | 17 |
| `net/minecraft/network/chat/Component#translationArg` | method | 1 |
| `net/minecraft/network/chat/FormattedText#getString` | method | 1 |
| `net/minecraft/network/chat/MutableComponent#getString` | method | 1 |
| `net/minecraft/network/codec/ByteBufCodecs#BOOL` | field | 3 |
| `net/minecraft/network/codec/ByteBufCodecs#STRING_UTF8` | field | 2 |
| `net/minecraft/network/codec/ByteBufCodecs#VAR_INT` | field | 2 |
| `net/minecraft/network/codec/ByteBufCodecs#idMapper` | method | 1 |
| `net/minecraft/network/codec/ByteBufCodecs#map` | method | 2 |
| `net/minecraft/network/codec/StreamCodec#composite` | method | 10 |
| `net/minecraft/network/codec/StreamCodec#decode` | method | 1 |
| `net/minecraft/network/codec/StreamCodec#encode` | method | 1 |
| `net/minecraft/network/codec/StreamCodec#of` | method | 2 |
| `net/minecraft/network/codec/StreamCodec$CodecOperation#apply` | method | 5 |
| `net/minecraft/network/protocol/common/custom/CustomPacketPayload$Type#<init>` | method | 1 |
| `net/minecraft/resources/Identifier#CODEC` | field | 4 |
| `net/minecraft/resources/Identifier#STREAM_CODEC` | field | 8 |
| `net/minecraft/resources/Identifier#equals` | method | 6 |
| `net/minecraft/resources/Identifier#fromNamespaceAndPath` | method | 10 |
| `net/minecraft/resources/Identifier#getNamespace` | method | 2 |
| `net/minecraft/resources/Identifier#getPath` | method | 2 |
| `net/minecraft/resources/Identifier#hashCode` | method | 2 |
| `net/minecraft/resources/Identifier#parse` | method | 2 |
| `net/minecraft/resources/Identifier#read` | method | 2 |
| `net/minecraft/resources/Identifier#toString` | method | 9 |
| `net/minecraft/resources/Identifier#tryParse` | method | 6 |
| `net/minecraft/resources/Identifier#withDefaultNamespace` | method | 2 |
| `net/minecraft/resources/ResourceKey#create` | method | 5 |
| `net/minecraft/resources/ResourceKey#identifier` | method | 1 |
| `net/minecraft/server/MinecraftServer#execute` | method | 1 |
| `net/minecraft/server/MinecraftServer#getTickCount` | method | 1 |
| `net/minecraft/server/PlayerAdvancements#unregisterListeners` | method | 1 |
| `net/minecraft/server/level/ServerLevel#dimension` | method | 1 |
| `net/minecraft/server/level/ServerLevel#setBlockAndUpdate` | method | 1 |
| `net/minecraft/server/level/ServerPlayer#connection` | field | 1 |
| `net/minecraft/server/level/ServerPlayer#isSleeping` | method | 1 |
| `net/minecraft/server/level/ServerPlayer#level` | method | 1 |
| `net/minecraft/server/level/ServerPlayer#sendSystemMessage` | method | 1 |
| `net/minecraft/server/network/ServerGamePacketListenerImpl#isAcceptingMessages` | method | 1 |
| `net/minecraft/server/network/ServerLoginPacketListenerImpl#disconnect` | method | 1 |
| `net/minecraft/server/packs/PackType#SERVER_DATA` | field | 1 |
| `net/minecraft/server/packs/resources/PreparableReloadListener$SharedState#get` | method | 2 |
| `net/minecraft/server/permissions/PermissionSet#hasPermission` | method | 1 |
| `net/minecraft/server/permissions/Permissions#COMMANDS_GAMEMASTER` | field | 1 |
| `net/minecraft/tags/DamageTypeTags#BYPASSES_INVULNERABILITY` | field | 1 |
| `net/minecraft/tags/FluidTags#WATER` | field | 1 |
| `net/minecraft/tags/TagKey#create` | method | 1 |
| `net/minecraft/util/ByIdMap#continuous` | method | 1 |
| `net/minecraft/util/ByIdMap$OutOfBoundsStrategy#CLAMP` | field | 1 |
| `net/minecraft/util/GsonHelper#getAsBoolean` | method | 4 |
| `net/minecraft/util/GsonHelper#getAsInt` | method | 2 |
| `net/minecraft/util/GsonHelper#getAsString` | method | 2 |
| `net/minecraft/util/RandomSource#nextDouble` | method | 2 |
| `net/minecraft/util/RandomSource#nextGaussian` | method | 2 |
| `net/minecraft/util/RandomSource#nextInt` | method | 1 |
| `net/minecraft/world/InteractionResult#CONSUME` | field | 1 |
| `net/minecraft/world/damagesource/DamageSource#<init>` | method | 1 |
| `net/minecraft/world/damagesource/DamageSource#is` | method | 1 |
| `net/minecraft/world/effect/MobEffects#CONDUIT_POWER` | field | 1 |
| `net/minecraft/world/effect/MobEffects#WATER_BREATHING` | field | 1 |
| `net/minecraft/world/entity/Entity#<init>` | method | 2 |
| `net/minecraft/world/entity/Entity#fallDistance` | field | 1 |
| `net/minecraft/world/entity/Entity#isAlive` | method | 1 |
| `net/minecraft/world/entity/Entity#isInvulnerableToBase` | method | 1 |
| `net/minecraft/world/entity/Entity#isPassenger` | method | 1 |
| `net/minecraft/world/entity/Entity#level` | method | 1 |
| `net/minecraft/world/entity/Entity#placePortalTicket` | method | 1 |
| `net/minecraft/world/entity/Entity#position` | method | 1 |
| `net/minecraft/world/entity/Entity#teleportTo` | method | 1 |
| `net/minecraft/world/entity/EntitySelector#NO_CREATIVE_OR_SPECTATOR` | field | 1 |
| `net/minecraft/world/entity/EntityType$Builder#build` | method | 1 |
| `net/minecraft/world/entity/EntityType$Builder#clientTrackingRange` | method | 1 |
| `net/minecraft/world/entity/EntityType$Builder#of` | method | 1 |
| `net/minecraft/world/entity/EntityType$Builder#sized` | method | 1 |
| `net/minecraft/world/entity/EntityType$Builder#updateInterval` | method | 1 |
| `net/minecraft/world/entity/LivingEntity#<init>` | method | 2 |
| `net/minecraft/world/entity/LivingEntity#canBreatheUnderwater` | method | 1 |
| `net/minecraft/world/entity/LivingEntity#getFluidFallingAdjustedMovement` | method | 1 |
| `net/minecraft/world/entity/LivingEntity#travelInWater` | method | 1 |
| `net/minecraft/world/entity/MobCategory#MISC` | field | 1 |
| `net/minecraft/world/entity/ai/goal/AvoidEntityGoal#<init>` | method | 1 |
| `net/minecraft/world/entity/ai/goal/GoalSelector#addGoal` | method | 2 |
| `net/minecraft/world/entity/ai/goal/target/NearestAttackableTargetGoal#<init>` | method | 1 |
| `net/minecraft/world/entity/monster/Creeper#registerGoals` | method | 2 |
| `net/minecraft/world/entity/monster/Monster#<init>` | method | 1 |
| `net/minecraft/world/entity/player/Player#getGameProfile` | method | 2 |
| `net/minecraft/world/entity/player/Player#getItemInHand` | method | 1 |
| `net/minecraft/world/entity/player/Player#getName` | method | 1 |
| `net/minecraft/world/entity/player/Player#getRandom` | method | 1 |
| `net/minecraft/world/entity/player/Player#isCreative` | method | 1 |
| `net/minecraft/world/entity/player/Player#isInWaterOrRain` | method | 1 |
| `net/minecraft/world/entity/player/Player#level` | method | 1 |
| `net/minecraft/world/entity/projectile/throwableitemprojectile/ThrowableItemProjectile#<init>` | method | 2 |
| `net/minecraft/world/entity/projectile/throwableitemprojectile/ThrowableItemProjectile#onHit` | method | 1 |
| `net/minecraft/world/entity/projectile/throwableitemprojectile/ThrowableItemProjectile#teleport` | method | 1 |
| `net/minecraft/world/entity/projectile/throwableitemprojectile/ThrowableItemProjectile#tick` | method | 1 |
| `net/minecraft/world/inventory/MenuType#GENERIC_3x3` | field | 1 |
| `net/minecraft/world/inventory/MenuType#GENERIC_9x1` | field | 1 |
| `net/minecraft/world/inventory/MenuType#GENERIC_9x2` | field | 1 |
| `net/minecraft/world/inventory/MenuType#GENERIC_9x3` | field | 1 |
| `net/minecraft/world/inventory/MenuType#GENERIC_9x4` | field | 1 |
| `net/minecraft/world/inventory/MenuType#GENERIC_9x5` | field | 1 |
| `net/minecraft/world/inventory/MenuType#GENERIC_9x6` | field | 1 |
| `net/minecraft/world/item/BlockItem#<init>` | method | 1 |
| `net/minecraft/world/item/CreativeModeTabs#TOOLS_AND_UTILITIES` | field | 1 |
| `net/minecraft/world/item/Item#builtInRegistryHolder` | method | 1 |
| `net/minecraft/world/item/Item#getDefaultInstance` | method | 1 |
| `net/minecraft/world/item/Item$Properties#<init>` | method | 2 |
| `net/minecraft/world/item/Item$Properties#rarity` | method | 1 |
| `net/minecraft/world/item/Item$Properties#setId` | method | 1 |
| `net/minecraft/world/item/ItemStack#<init>` | method | 2 |
| `net/minecraft/world/item/ItemStack#EMPTY` | field | 2 |
| `net/minecraft/world/item/ItemStack#OPTIONAL_STREAM_CODEC` | field | 2 |
| `net/minecraft/world/item/ItemStack#get` | method | 1 |
| `net/minecraft/world/item/ItemStack#getItem` | method | 2 |
| `net/minecraft/world/item/ItemStack#has` | method | 3 |
| `net/minecraft/world/item/ItemStack#set` | method | 2 |
| `net/minecraft/world/item/ItemStackTemplate#<init>` | method | 1 |
| `net/minecraft/world/item/Items#AIR` | field | 1 |
| `net/minecraft/world/item/Items#ENCHANTED_BOOK` | field | 1 |
| `net/minecraft/world/item/Items#ENDER_PEARL` | field | 1 |
| `net/minecraft/world/item/Items#PLAYER_HEAD` | field | 2 |
| `net/minecraft/world/item/Rarity#RARE` | field | 1 |
| `net/minecraft/world/item/component/ResolvableProfile#createResolved` | method | 2 |
| `net/minecraft/world/item/crafting/CraftingInput#of` | method | 1 |
| `net/minecraft/world/item/crafting/Ingredient#items` | method | 1 |
| `net/minecraft/world/item/crafting/PlacementInfo#ingredients` | method | 1 |
| `net/minecraft/world/item/crafting/Recipe#placementInfo` | method | 1 |
| `net/minecraft/world/item/crafting/ShapedRecipe#getWidth` | method | 1 |
| `net/minecraft/world/level/Level#addParticle` | method | 2 |
| `net/minecraft/world/level/Level#dimension` | method | 1 |
| `net/minecraft/world/level/block/Block#defaultBlockState` | method | 1 |
| `net/minecraft/world/level/block/Blocks#AIR` | field | 1 |
| `net/minecraft/world/level/block/WebBlock#<init>` | method | 1 |
| `net/minecraft/world/level/block/WebBlock#entityInside` | method | 1 |
| `net/minecraft/world/level/block/WebBlock#onPlace` | method | 1 |
| `net/minecraft/world/level/block/entity/ConduitBlockEntity#applyEffects` | method | 1 |
| `net/minecraft/world/level/block/state/BlockBehaviour$Properties#forceSolidOn` | method | 1 |
| `net/minecraft/world/level/block/state/BlockBehaviour$Properties#mapColor` | method | 1 |
| `net/minecraft/world/level/block/state/BlockBehaviour$Properties#noCollision` | method | 1 |
| `net/minecraft/world/level/block/state/BlockBehaviour$Properties#of` | method | 1 |
| `net/minecraft/world/level/block/state/BlockBehaviour$Properties#requiresCorrectToolForDrops` | method | 1 |
| `net/minecraft/world/level/block/state/BlockBehaviour$Properties#setId` | method | 1 |
| `net/minecraft/world/level/block/state/BlockBehaviour$Properties#strength` | method | 1 |
| `net/minecraft/world/level/material/MapColor#WOOL` | field | 1 |
| `net/minecraft/world/level/portal/TeleportTransition#newLevel` | method | 1 |
| `net/minecraft/world/level/storage/ValueInput#childOrEmpty` | method | 1 |
| `net/minecraft/world/level/storage/ValueInput#childrenList` | method | 1 |
| `net/minecraft/world/level/storage/ValueInput#getBooleanOr` | method | 1 |
| `net/minecraft/world/level/storage/ValueInput#getString` | method | 1 |
| `net/minecraft/world/level/storage/ValueInput#getStringOr` | method | 1 |
| `net/minecraft/world/level/storage/ValueInput#read` | method | 1 |
| `net/minecraft/world/level/storage/ValueInput$ValueInputList#iterator` | method | 1 |
| `net/minecraft/world/level/storage/ValueOutput#childrenList` | method | 1 |
| `net/minecraft/world/level/storage/ValueOutput#putBoolean` | method | 1 |
| `net/minecraft/world/level/storage/ValueOutput#putString` | method | 1 |
| `net/minecraft/world/level/storage/ValueOutput$ValueOutputList#addChild` | method | 1 |
| `net/minecraft/world/level/storage/loot/LootContext#getOptional` | method | 1 |
| `net/minecraft/world/level/storage/loot/LootPool$Builder#<init>` | method | 1 |
| `net/minecraft/world/level/storage/loot/LootPool$Builder#add` | method | 1 |
| `net/minecraft/world/level/storage/loot/LootPool$Builder#setRolls` | method | 1 |
| `net/minecraft/world/level/storage/loot/LootTable$Builder#withPool` | method | 1 |
| `net/minecraft/world/level/storage/loot/entries/EmptyLootItem#emptyItem` | method | 1 |
| `net/minecraft/world/level/storage/loot/entries/LootItem#lootTableItem` | method | 1 |
| `net/minecraft/world/level/storage/loot/entries/UniformContainerBase$Builder#apply` | method | 1 |
| `net/minecraft/world/level/storage/loot/entries/UniformContainerBase$Builder#setWeight` | method | 1 |
| `net/minecraft/world/level/storage/loot/functions/SetEnchantmentsFunction$Builder#<init>` | method | 1 |
| `net/minecraft/world/level/storage/loot/functions/SetEnchantmentsFunction$Builder#withEnchantment` | method | 1 |
| `net/minecraft/world/level/storage/loot/parameters/LootContextParams#THIS_ENTITY` | field | 1 |
| `net/minecraft/world/level/storage/loot/predicates/LootItemCondition#CODEC` | field | 1 |
| `net/minecraft/world/level/storage/loot/providers/number/ints/ContextIntProviders#exactly` | method | 1 |
| `net/minecraft/world/phys/Vec3#<init>` | method | 1 |
| `net/minecraft/world/phys/Vec3#x` | field | 1 |
| `net/minecraft/world/phys/Vec3#y` | field | 1 |
| `net/minecraft/world/phys/Vec3#z` | field | 1 |
| `net/minecraft/world/phys/shapes/Shapes#empty` | method | 1 |

</details>

